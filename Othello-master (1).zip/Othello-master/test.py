from partie3 import *

print(creer_partie(4))

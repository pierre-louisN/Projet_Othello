from partie1 import *

plateau=creer_plateau(4)

set_case(plateau,0,0,1)
set_case(plateau,3,1,2)

afficher_plateau(plateau)
print()


plateau=creer_plateau(6)

set_case(plateau,2,4,1)
set_case(plateau,2,2,1)

afficher_plateau(plateau)
print()


plateau=creer_plateau(8)

set_case(plateau,5,6,2)
set_case(plateau,4,4,1)

afficher_plateau(plateau)

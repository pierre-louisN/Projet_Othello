from partie3 import *

othello()
